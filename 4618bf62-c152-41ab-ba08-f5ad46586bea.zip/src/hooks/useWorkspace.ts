import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { records as initialRecords } from '../data/records';
import { fictionalExamples } from '../data/fictionalExamples';
import { analyseRecords } from '../utils/leads';
import type { CaseRecord } from '../types/record';
import type { Lead, LeadFilter, LeadReview, LeadStatus } from '../types/lead';

const REVIEWER_ID = 'R-07';
const ANALYSIS_DURATION_MS = 650;

export function useWorkspace(sameAreaWindowDays: number, crossAreaWindowDays: number) {
  const [records, setRecords] = useState<CaseRecord[]>(initialRecords);
  const [analysedRecords, setAnalysedRecords] = useState<CaseRecord[]>(initialRecords);
  const [ranAt, setRanAt] = useState<Date>(() => new Date());
  const [isRunning, setIsRunning] = useState(false);
  const [reviews, setReviews] = useState<Record<string, LeadReview>>({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<LeadFilter>('all');
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const rules = useMemo(
    () => ({ sameAreaWindowDays, crossAreaWindowDays }),
    [sameAreaWindowDays, crossAreaWindowDays]
  );

  const { areaLeads, namedLeads } = useMemo(() => analyseRecords(analysedRecords, rules), [analysedRecords, rules]);
  const allLeads = useMemo(() => [...areaLeads, ...namedLeads], [areaLeads, namedLeads]);
  const recordMap = useMemo(() => new Map(analysedRecords.map((r) => [r.case_id, r])), [analysedRecords]);

  const statusFor = useCallback((id: string): LeadStatus => reviews[id]?.status ?? 'Unreviewed', [reviews]);

  const matchesFilter = useCallback(
    (lead: Lead) => {
      if (filter === 'all') return true;
      const reviewed = statusFor(lead.id) !== 'Unreviewed';
      return filter === 'reviewed' ? reviewed : !reviewed;
    },
    [filter, statusFor]
  );

  const selectedLead = allLeads.find((l) => l.id === selectedId) ?? allLeads[0] ?? null;
  const relatedLeads = selectedLead ?
  allLeads.filter(
    (l) =>
    l.id !== selectedLead.id &&
    [l.caseA, l.caseB].some((id) => id === selectedLead.caseA || id === selectedLead.caseB)
  ) :
  [];

  const runAnalysis = useCallback(() => {
    window.clearTimeout(timer.current);
    setIsRunning(true);
    timer.current = window.setTimeout(() => {
      setAnalysedRecords(records);
      setRanAt(new Date());
      setIsRunning(false);
    }, ANALYSIS_DURATION_MS);
  }, [records]);

  const reset = useCallback(() => {
    window.clearTimeout(timer.current);
    setIsRunning(false);
    setRecords(initialRecords);
    setAnalysedRecords(initialRecords);
    setReviews({});
    setSelectedId(null);
    setFilter('all');
    setRanAt(new Date());
  }, []);

  const addedCount = records.length - initialRecords.length;
  const nextExample = fictionalExamples[addedCount];

  const addExample = useCallback(() => {
    if (!nextExample) return;
    setRecords((prev) => [...prev, nextExample]);
  }, [nextExample]);

  const saveDecision = useCallback((leadId: string, status: LeadStatus, note: string) => {
    setReviews((prev) => ({
      ...prev,
      [leadId]: {
        status,
        history: [
        { status, note: note.trim(), at: new Date().toISOString(), reviewer: REVIEWER_ID },
        ...(prev[leadId]?.history ?? [])]

      }
    }));
  }, []);

  return {
    rules,
    records,
    recordMap,
    areaLeads: areaLeads.filter(matchesFilter),
    namedLeads: namedLeads.filter(matchesFilter),
    totalLeads: allLeads.length,
    reviewedCount: allLeads.filter((l) => statusFor(l.id) !== 'Unreviewed').length,
    selectedLead,
    relatedLeads,
    reviews,
    statusFor,
    filter,
    setFilter,
    select: setSelectedId,
    isRunning,
    ranAt,
    pendingRecords: records.length - analysedRecords.length,
    canAddExample: Boolean(nextExample),
    runAnalysis,
    reset,
    addExample,
    saveDecision,
    reviewerId: REVIEWER_ID
  };
}