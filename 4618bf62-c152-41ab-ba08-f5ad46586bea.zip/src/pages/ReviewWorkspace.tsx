import React from 'react';
import { TopBar } from '../components/TopBar';
import { LeadsList } from '../components/LeadsList';
import { LeadDetail } from '../components/LeadDetail';
import { ReviewPanel } from '../components/ReviewPanel';
import { useWorkspace } from '../hooks/useWorkspace';
import { records as initialRecords } from '../data/records';

interface ReviewWorkspaceProps {
  sameAreaWindowDays: number;
  crossAreaWindowDays: number;
}

export function ReviewWorkspace({ sameAreaWindowDays, crossAreaWindowDays }: ReviewWorkspaceProps) {
  const ws = useWorkspace(sameAreaWindowDays, crossAreaWindowDays);
  const lead = ws.selectedLead;
  const recordA = lead ? ws.recordMap.get(lead.caseA) : undefined;
  const recordB = lead ? ws.recordMap.get(lead.caseB) : undefined;

  return (
    <div className="flex h-screen w-full min-w-[1180px] flex-col bg-canvas font-sans text-ink antialiased">
      <TopBar
        recordCount={ws.records.length}
        originalCount={initialRecords.length}
        leadCount={ws.totalLeads}
        isRunning={ws.isRunning}
        pendingRecords={ws.pendingRecords}
        ranAt={ws.ranAt}
        canAddExample={ws.canAddExample}
        onRun={ws.runAnalysis}
        onReset={ws.reset}
        onAddExample={ws.addExample} />
      
      <div className="grid min-h-0 flex-1 grid-cols-[340px_minmax(0,1fr)_340px]">
        <aside aria-label="Leads" className="min-h-0 overflow-y-auto border-r border-line bg-surface">
          <LeadsList
            areaLeads={ws.areaLeads}
            namedLeads={ws.namedLeads}
            rules={ws.rules}
            filter={ws.filter}
            onFilterChange={ws.setFilter}
            selectedId={lead?.id ?? null}
            statusFor={ws.statusFor}
            onSelect={ws.select}
            isRunning={ws.isRunning} />
          
        </aside>

        <main className="min-h-0 overflow-y-auto">
          {lead && recordA && recordB ?
          <LeadDetail
            lead={lead}
            recordA={recordA}
            recordB={recordB}
            status={ws.statusFor(lead.id)}
            rules={ws.rules}
            relatedLeads={ws.relatedLeads}
            statusFor={ws.statusFor}
            onSelect={ws.select} /> :


          <div className="flex h-full items-center justify-center px-8">
              <div className="max-w-sm text-center">
                <p className="text-[14px] font-semibold text-ink">No possible leads to review</p>
                <p className="mt-1 text-[13px] leading-relaxed text-ink-muted">
                  The current rules found no leads. Add a fictional example or adjust the rules, then run analysis again.
                </p>
              </div>
            </div>
          }
        </main>

        <aside aria-label="Reviewer decision" className="min-h-0 overflow-y-auto border-l border-line bg-surface">
          {lead &&
          <ReviewPanel
            key={lead.id}
            lead={lead}
            review={ws.reviews[lead.id]}
            reviewerId={ws.reviewerId}
            reviewedCount={ws.reviewedCount}
            totalCount={ws.totalLeads}
            onSave={ws.saveDecision} />

          }
        </aside>
      </div>
    </div>);

}