import React from 'react';
import { MotionConfig } from 'framer-motion';
import { ReviewWorkspace } from './pages/ReviewWorkspace';

interface AppProps {
  /** Records in the same area reported within this many days become a lead. */
  sameAreaWindowDays?: number;
  /** Records in different areas reported within this many days become a lead. */
  crossAreaWindowDays?: number;
}

export function App({ sameAreaWindowDays = 14, crossAreaWindowDays = 3 }: AppProps) {
  return (
    <MotionConfig reducedMotion="user">
      <ReviewWorkspace sameAreaWindowDays={sameAreaWindowDays} crossAreaWindowDays={crossAreaWindowDays} />
    </MotionConfig>);

}