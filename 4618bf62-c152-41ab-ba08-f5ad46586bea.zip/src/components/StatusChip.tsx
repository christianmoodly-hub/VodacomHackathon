import React from "react";
import { CheckIcon, CircleDashedIcon, HelpCircleIcon, MinusIcon, BoxIcon } from "lucide-react";
import { LeadStatus } from "../types/lead";
interface StatusChipProps {
  status: LeadStatus;
}
const styles: Record<LeadStatus, {
  cls: string;
  Icon: BoxIcon;
}> = {
  Unreviewed: {
    cls: 'border-line-strong bg-surface text-ink-muted',
    Icon: CircleDashedIcon
  },
  Verified: {
    cls: 'border-transparent bg-verified-soft text-verified',
    Icon: CheckIcon
  },
  'Needs more info': {
    cls: 'border-transparent bg-info-soft text-info',
    Icon: HelpCircleIcon
  },
  Dismissed: {
    cls: 'border-transparent bg-dismissed-soft text-dismissed',
    Icon: MinusIcon
  }
};
export function StatusChip({
  status
}: StatusChipProps) {
  const {
    cls,
    Icon
  } = styles[status];
  return <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[11px] font-medium ${cls}`}>
      <Icon className="h-3 w-3" strokeWidth={2.25} aria-hidden="true" />
      {status}
    </span>;
}