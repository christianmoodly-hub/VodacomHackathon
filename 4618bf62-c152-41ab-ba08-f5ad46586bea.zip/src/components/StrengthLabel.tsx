import React from 'react';
import { LevelMeter } from './LevelMeter';
import type { LeadStrength } from '../types/lead';

interface StrengthLabelProps {
  strength: LeadStrength;
  className?: string;
}

const filledFor: Record<LeadStrength, 1 | 2 | 3> = { Strong: 3, Moderate: 2, Weak: 1 };

export function StrengthLabel({ strength, className }: StrengthLabelProps) {
  return <LevelMeter filled={filledFor[strength]} label={strength} srPrefix="Lead strength" className={className} />;
}