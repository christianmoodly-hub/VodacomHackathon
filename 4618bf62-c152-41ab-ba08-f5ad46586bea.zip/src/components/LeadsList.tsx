import React from 'react';
import { LeadGroup } from './LeadGroup';
import type { AnalysisRules, Lead, LeadFilter, LeadStatus } from '../types/lead';

interface LeadsListProps {
  areaLeads: Lead[];
  namedLeads: Lead[];
  rules: AnalysisRules;
  filter: LeadFilter;
  onFilterChange: (f: LeadFilter) => void;
  selectedId: string | null;
  statusFor: (id: string) => LeadStatus;
  onSelect: (id: string) => void;
  isRunning: boolean;
}

const filters: {value: LeadFilter;label: string;}[] = [
{ value: 'all', label: 'All' },
{ value: 'unreviewed', label: 'Unreviewed' },
{ value: 'reviewed', label: 'Reviewed' }];


export function LeadsList({
  areaLeads,
  namedLeads,
  rules,
  filter,
  onFilterChange,
  selectedId,
  statusFor,
  onSelect,
  isRunning
}: LeadsListProps) {
  const emptyText = filter === 'all' ? 'No leads found by this rule.' : 'No leads in this view.';

  return (
    <div className={`transition-opacity duration-200 ease-out ${isRunning ? 'opacity-50' : 'opacity-100'}`} aria-busy={isRunning}>
      <div className="sticky top-0 z-10 border-b border-line bg-surface px-4 pb-3 pt-4">
        <h1 className="text-[15px] font-semibold tracking-tight text-ink">Possible leads</h1>
        <div role="radiogroup" aria-label="Filter leads by review status" className="mt-3 grid grid-cols-3 rounded-md bg-canvas p-0.5">
          {filters.map((f) => {
            const active = filter === f.value;
            return (
              <button
                key={f.value}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => onFilterChange(f.value)}
                className={`h-7 rounded-[5px] text-[12px] font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 ${
                active ? 'bg-surface text-ink shadow-sm' : 'text-ink-muted hover:text-ink'}`
                }>
                
                {f.label}
              </button>);

          })}
        </div>
      </div>

      <LeadGroup
        id="group-area-timing"
        title="Area / timing leads"
        description={`Same area within ${rules.sameAreaWindowDays} days, or different areas within ${rules.crossAreaWindowDays} days.`}
        leads={areaLeads}
        emptyText={emptyText}
        selectedId={selectedId}
        statusFor={statusFor}
        onSelect={onSelect} />
      
      <div className="mx-4 h-px bg-line" aria-hidden="true" />
      <LeadGroup
        id="group-named"
        title="Links named in the data"
        description="A record names another case as possibly related. Shown whether or not area and timing agree."
        leads={namedLeads}
        emptyText={emptyText}
        selectedId={selectedId}
        statusFor={statusFor}
        onSelect={onSelect} />
      
    </div>);

}