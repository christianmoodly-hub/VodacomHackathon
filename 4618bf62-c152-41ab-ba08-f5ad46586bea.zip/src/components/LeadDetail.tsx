import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeftRightIcon, ArrowRightIcon, CheckIcon, InfoIcon, MinusIcon } from 'lucide-react';
import { RecordComparison } from './RecordComparison';
import { StatusChip } from './StatusChip';
import { StrengthLabel } from './StrengthLabel';
import { assessEvidence } from '../utils/leads';
import type { CaseRecord } from '../types/record';
import type { AnalysisRules, Lead, LeadStatus } from '../types/lead';

interface LeadDetailProps {
  lead: Lead;
  recordA: CaseRecord;
  recordB: CaseRecord;
  status: LeadStatus;
  rules: AnalysisRules;
  relatedLeads: Lead[];
  statusFor: (id: string) => LeadStatus;
  onSelect: (id: string) => void;
}

export function LeadDetail({ lead, recordA, recordB, status, rules, relatedLeads, statusFor, onSelect }: LeadDetailProps) {
  const isNamed = lead.source === 'named';
  const evidence = assessEvidence(recordA, recordB, rules);

  return (
    <motion.article
      key={lead.id}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15, ease: 'easeOut' }}
      className="mx-auto w-full max-w-[900px] px-8 py-7"
      aria-labelledby="lead-title">
      
      <p className="text-[12.5px] text-ink-muted">
        Possible lead · {isNamed ? 'Named in the data' : 'Found by area / timing rule'}
      </p>
      <h2 id="lead-title" className="mt-1 flex flex-wrap items-center gap-2 font-mono text-[20px] font-semibold tracking-tight text-ink">
        {lead.caseA}
        {isNamed ?
        <ArrowRightIcon className="h-4 w-4 text-ink-subtle" aria-label="names" /> :

        <ArrowLeftRightIcon className="h-4 w-4 text-ink-subtle" aria-label="and" />
        }
        {lead.caseB}
      </h2>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
        <span className="text-[13.5px] text-ink">{lead.reason}</span>
        <StrengthLabel strength={lead.strength} className="text-[12.5px] text-ink-muted" />
        <StatusChip status={status} />
      </div>

      <div className="mt-5 flex gap-2.5 rounded-lg border border-line bg-surface px-4 py-3">
        <InfoIcon className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
        <div className="text-[12.5px] leading-relaxed text-ink-muted">
          <p>
            <span className="font-medium text-ink">Needs verification.</span> This lead was raised automatically from
            synthetic data. It is not a finding. A reviewer decides whether it is worth pursuing.
          </p>
          {isNamed && !lead.supported &&
          <p className="mt-1.5">
              <span className="font-medium text-ink">Not supported by area/timing.</span> {lead.caseA} names {lead.caseB},
              but they are in different areas or too far apart in time. It is shown here so a reviewer can assess it.
            </p>
          }
        </div>
      </div>

      <section aria-labelledby="compare-heading" className="mt-8">
        <h3 id="compare-heading" className="mb-3 text-[14px] font-semibold text-ink">
          Records side by side
        </h3>
        <RecordComparison a={recordA} b={recordB} daysApart={lead.daysApart} />
      </section>

      <section aria-labelledby="evidence-heading" className="mt-8">
        <h3 id="evidence-heading" className="text-[14px] font-semibold text-ink">
          Why this lead was raised
        </h3>
        <dl className="mt-3 divide-y divide-line border-y border-line">
          {evidence.map((item) =>
          <div key={item.label} className="grid grid-cols-[136px_minmax(0,1fr)_auto] items-center gap-3 py-3">
              <dt className="text-[12.5px] font-medium text-ink-muted">{item.label}</dt>
              <dd className="text-[13.5px] text-ink">{item.finding}</dd>
              <dd
              className={`inline-flex items-center gap-1 whitespace-nowrap text-[12px] font-medium ${
              item.supports ? 'text-accent' : 'text-ink-subtle'}`
              }>
              
                {item.supports ?
              <CheckIcon className="h-3.5 w-3.5" aria-hidden="true" /> :

              <MinusIcon className="h-3.5 w-3.5" aria-hidden="true" />
              }
                {item.supports ? 'Supports lead' : 'Does not support'}
              </dd>
            </div>
          )}
        </dl>
      </section>

      <section aria-labelledby="related-heading" className="mt-8">
        <h3 id="related-heading" className="text-[14px] font-semibold text-ink">
          Other possible leads involving these records
        </h3>
        {relatedLeads.length === 0 ?
        <p className="mt-2 text-[13px] text-ink-subtle">No other leads involve {lead.caseA} or {lead.caseB}.</p> :

        <ul className="mt-2 divide-y divide-line border-y border-line">
            {relatedLeads.map((r) =>
          <li key={r.id}>
                <button
              type="button"
              onClick={() => onSelect(r.id)}
              className="grid w-full grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-4 px-1 py-2.5 text-left transition-colors duration-150 ease-out hover:bg-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40">
              
                  <span className="min-w-0">
                    <span className="font-mono text-[12.5px] font-medium text-ink">
                      {r.caseA} {r.source === 'named' ? '→' : '·'} {r.caseB}
                    </span>
                    <span className="ml-3 text-[12.5px] text-ink-muted">
                      {r.source === 'named' ? 'Named in data' : 'Area / timing'} · {r.reason}
                    </span>
                  </span>
                  <StrengthLabel strength={r.strength} />
                  <StatusChip status={statusFor(r.id)} />
                </button>
              </li>
          )}
          </ul>
        }
      </section>
    </motion.article>);

}