import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { RotateCcwIcon } from 'lucide-react';

interface ResetButtonProps {
  originalCount: number;
  onConfirm: () => void;
}

export function ResetButton({ originalCount, onConfirm }: ResetButtonProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="dialog"
        className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md px-2.5 text-[13px] font-medium text-ink-muted transition-colors duration-150 ease-out hover:bg-canvas hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40">
        
        <RotateCcwIcon className="h-3.5 w-3.5" aria-hidden="true" />
        Reset
      </button>
      <AnimatePresence>
        {open &&
        <motion.div
          role="dialog"
          aria-label="Confirm reset"
          initial={{ opacity: 0, y: -4, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -4, scale: 0.97 }}
          transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
          className="absolute right-0 top-10 z-20 w-72 origin-top-right rounded-lg border border-line bg-surface p-4 shadow-lg shadow-ink/5">
          
            <p className="text-[13px] font-semibold text-ink">Reset the workspace?</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-ink-muted">
              This restores the original {originalCount} synthetic records and clears every reviewer decision and note.
            </p>
            <div className="mt-3 flex justify-end gap-2">
              <button
              type="button"
              onClick={() => setOpen(false)}
              className="h-8 rounded-md px-3 text-[12.5px] font-medium text-ink-muted transition-colors duration-150 ease-out hover:bg-canvas hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40">
              
                Cancel
              </button>
              <button
              type="button"
              onClick={() => {
                onConfirm();
                setOpen(false);
              }}
              className="h-8 rounded-md border border-line-strong bg-surface px-3 text-[12.5px] font-medium text-ink transition-colors duration-150 ease-out hover:bg-canvas focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40">
              
                Reset workspace
              </button>
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}