import React from 'react';

interface LevelMeterProps {
  filled: 1 | 2 | 3;
  label: string;
  srPrefix: string;
  className?: string;
}

export function LevelMeter({ filled, label, srPrefix, className = 'text-[11.5px] text-ink-muted' }: LevelMeterProps) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap font-medium ${className}`}>
      <span className="flex items-end gap-[2px]" aria-hidden="true">
        {[1, 2, 3].map((i) =>
        <span
          key={i}
          className={`w-[3px] rounded-[1px] ${i <= filled ? 'bg-ink-muted' : 'bg-line-strong'}`}
          style={{ height: 3 + i * 2.5 }} />

        )}
      </span>
      <span className="sr-only">{srPrefix}: </span>
      {label}
    </span>);

}