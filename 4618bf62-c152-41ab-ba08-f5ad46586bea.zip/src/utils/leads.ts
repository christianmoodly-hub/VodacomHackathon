import type { CaseRecord } from '../types/record';
import type { AnalysisRules, EvidenceItem, Lead, LeadStrength } from '../types/lead';

const DAY_MS = 86_400_000;
export const STRONG_WITHIN_DAYS = 7;

const strengthRank: Record<LeadStrength, number> = { Strong: 0, Moderate: 1, Weak: 2 };

export function daysBetween(a: string, b: string): number {
  return Math.round(Math.abs(Date.parse(a) - Date.parse(b)) / DAY_MS);
}

export function formatGap(days: number): string {
  if (days === 0) return 'same day';
  return `${days} ${days === 1 ? 'day' : 'days'} apart`;
}

function pairKey(a: string, b: string): string {
  return [a, b].sort().join('|');
}

function describePair(a: CaseRecord, b: CaseRecord, days: number): string {
  const area = a.area_code === b.area_code ? a.area_code : `${a.area_code} and ${b.area_code}`;
  return `${area}, ${formatGap(days)}`;
}

function areaTimingStrength(sameArea: boolean, days: number, rules: AnalysisRules): LeadStrength | null {
  if (sameArea) {
    if (days > rules.sameAreaWindowDays) return null;
    return days <= STRONG_WITHIN_DAYS ? 'Strong' : 'Moderate';
  }
  return days <= rules.crossAreaWindowDays ? 'Weak' : null;
}

export function findAreaTimingLeads(records: CaseRecord[], rules: AnalysisRules): Lead[] {
  const leads: Lead[] = [];
  for (let i = 0; i < records.length; i++) {
    for (let j = i + 1; j < records.length; j++) {
      const [a, b] = [records[i], records[j]].sort(
        (x, y) => x.date_reported.localeCompare(y.date_reported) || x.case_id.localeCompare(y.case_id)
      );
      const days = daysBetween(a.date_reported, b.date_reported);
      const sameArea = a.area_code === b.area_code;
      const strength = areaTimingStrength(sameArea, days, rules);
      if (!strength) continue;
      leads.push({
        id: `at:${pairKey(a.case_id, b.case_id)}`,
        source: 'area-timing',
        caseA: a.case_id,
        caseB: b.case_id,
        reason: describePair(a, b, days),
        strength,
        daysApart: days,
        sameArea,
        supported: true
      });
    }
  }
  return leads.sort((x, y) => strengthRank[x.strength] - strengthRank[y.strength] || x.daysApart - y.daysApart);
}

export function findNamedLeads(records: CaseRecord[], rules: AnalysisRules): Lead[] {
  const byId = new Map(records.map((r) => [r.case_id, r]));
  return records.flatMap((r) => {
    const ref = r.possible_linked_case_ref;
    if (!ref || ref === r.case_id) return [];
    const target = byId.get(ref);
    if (!target) return [];
    const days = daysBetween(r.date_reported, target.date_reported);
    const sameArea = r.area_code === target.area_code;
    const strength = areaTimingStrength(sameArea, days, rules);
    return [
    {
      id: `nl:${r.case_id}>${target.case_id}`,
      source: 'named' as const,
      caseA: r.case_id,
      caseB: target.case_id,
      reason: describePair(r, target, days),
      strength: strength ?? 'Weak',
      daysApart: days,
      sameArea,
      supported: strength !== null
    }];

  });
}

export function analyseRecords(records: CaseRecord[], rules: AnalysisRules) {
  return {
    areaLeads: findAreaTimingLeads(records, rules),
    namedLeads: findNamedLeads(records, rules)
  };
}

export function assessEvidence(a: CaseRecord, b: CaseRecord, rules: AnalysisRules): EvidenceItem[] {
  const days = daysBetween(a.date_reported, b.date_reported);
  const sameArea = a.area_code === b.area_code;
  const window = sameArea ? rules.sameAreaWindowDays : rules.crossAreaWindowDays;
  const aNamesB = a.possible_linked_case_ref === b.case_id;
  const bNamesA = b.possible_linked_case_ref === a.case_id;

  let named = 'Neither record names the other';
  if (aNamesB && bNamesA) named = 'Each record names the other';else
  if (aNamesB) named = `${a.case_id} names ${b.case_id} as a possible related case`;else
  if (bNamesA) named = `${b.case_id} names ${a.case_id} as a possible related case`;

  return [
  {
    label: 'Area',
    finding: sameArea ? `Both records are in ${a.area_code}` : `${a.area_code} and ${b.area_code} are different areas`,
    supports: sameArea
  },
  {
    label: 'Timing',
    finding: `Reported ${days === 0 ? 'on the same day' : formatGap(days)}. The window for ${sameArea ? 'the same area' : 'different areas'} is ${window} days.`,
    supports: days <= window
  },
  { label: 'Named in data', finding: named, supports: aNamesB || bNamesA }];

}