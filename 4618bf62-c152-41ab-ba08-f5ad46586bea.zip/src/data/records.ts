import type { CaseRecord } from '../types/record';

export const records: CaseRecord[] = [
{ case_id: 'CASE-SYN-1000', record_type: 'Missing person report', date_reported: '2026-03-02', area_code: 'Area-1', risk_indicator: 'High', possible_linked_case_ref: 'CASE-SYN-1003' },
{ case_id: 'CASE-SYN-1001', record_type: 'Case record', date_reported: '2026-03-14', area_code: 'Area-3', risk_indicator: 'Medium', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1002', record_type: 'Hotspot report', date_reported: '2026-03-29', area_code: 'Area-2', risk_indicator: 'Low', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1003', record_type: 'Case record', date_reported: '2026-03-08', area_code: 'Area-1', risk_indicator: 'High', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1004', record_type: 'Missing person report', date_reported: '2026-03-20', area_code: 'Area-4', risk_indicator: 'Medium', possible_linked_case_ref: 'CASE-SYN-1009' },
{ case_id: 'CASE-SYN-1005', record_type: 'Hotspot report', date_reported: '2026-03-24', area_code: 'Area-1', risk_indicator: 'Medium', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1006', record_type: 'Missing person report', date_reported: '2026-04-02', area_code: 'Area-2', risk_indicator: 'High', possible_linked_case_ref: 'CASE-SYN-1001' },
{ case_id: 'CASE-SYN-1007', record_type: 'Case record', date_reported: '2026-04-12', area_code: 'Area-2', risk_indicator: 'Medium', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1008', record_type: 'Case record', date_reported: '2026-04-22', area_code: 'Area-5', risk_indicator: 'Low', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1009', record_type: 'Case record', date_reported: '2026-03-22', area_code: 'Area-4', risk_indicator: 'Medium', possible_linked_case_ref: null },
{ case_id: 'CASE-SYN-1010', record_type: 'Missing person report', date_reported: '2026-04-24', area_code: 'Area-3', risk_indicator: 'Medium', possible_linked_case_ref: 'CASE-SYN-1008' },
{ case_id: 'CASE-SYN-1011', record_type: 'Hotspot report', date_reported: '2026-05-06', area_code: 'Area-5', risk_indicator: 'Low', possible_linked_case_ref: 'CASE-SYN-1004' }];