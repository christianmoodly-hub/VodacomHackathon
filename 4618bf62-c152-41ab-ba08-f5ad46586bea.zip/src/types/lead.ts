export type LeadSource = 'area-timing' | 'named';

export type LeadStrength = 'Strong' | 'Moderate' | 'Weak';

export type LeadStatus = 'Unreviewed' | 'Verified' | 'Needs more info' | 'Dismissed';

export type LeadFilter = 'all' | 'unreviewed' | 'reviewed';

export interface Lead {
  id: string;
  source: LeadSource;
  /** For named leads, caseA is the record that contains the reference. */
  caseA: string;
  caseB: string;
  reason: string;
  strength: LeadStrength;
  daysApart: number;
  sameArea: boolean;
  /** Whether area/timing rules also support this pair. Always true for area/timing leads. */
  supported: boolean;
}

export interface AnalysisRules {
  sameAreaWindowDays: number;
  crossAreaWindowDays: number;
}

export interface EvidenceItem {
  label: string;
  finding: string;
  supports: boolean;
}

export interface ReviewEntry {
  status: LeadStatus;
  note: string;
  at: string;
  reviewer: string;
}

export interface LeadReview {
  status: LeadStatus;
  history: ReviewEntry[];
}