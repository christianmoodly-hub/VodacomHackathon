export type RecordType = 'Missing person report' | 'Case record' | 'Hotspot report';

export type RiskIndicator = 'Low' | 'Medium' | 'High';

export type AreaCode = 'Area-1' | 'Area-2' | 'Area-3' | 'Area-4' | 'Area-5';

export interface CaseRecord {
  case_id: string;
  record_type: RecordType;
  date_reported: string;
  area_code: AreaCode;
  risk_indicator: RiskIndicator;
  possible_linked_case_ref: string | null;
}