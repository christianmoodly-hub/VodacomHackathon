export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        canvas: '#F4F5F7',
        surface: '#FFFFFF',
        ink: {
          DEFAULT: '#1B2430',
          muted: '#5B6675',
          subtle: '#8A93A0',
        },
        line: {
          DEFAULT: '#E2E5E9',
          strong: '#CDD2D8',
        },
        accent: {
          DEFAULT: '#2F5F6B',
          strong: '#234A54',
          soft: '#EAF1F2',
        },
        verified: {
          DEFAULT: '#3B6A55',
          soft: '#E7F0EB',
        },
        info: {
          DEFAULT: '#85631F',
          soft: '#F5EEDF',
        },
        dismissed: {
          DEFAULT: '#646B75',
          soft: '#ECEEF1',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
    },
  },
};
